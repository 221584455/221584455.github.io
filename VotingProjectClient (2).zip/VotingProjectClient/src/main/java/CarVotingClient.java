
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class CarVotingClient extends JFrame implements ActionListener {

    private static ObjectInputStream input;
    private static ObjectOutputStream output;
    private static Socket connection;

    private JPanel headerPanel, contentPanel, inputPanel, displayPanel, actionPanel;

    private JLabel titleLabel;
    private JLabel vehiclesLabel;
    private JComboBox<String> vehicleComboBox;

    private JLabel vehicleNameLabel;
    private JTextField vehicleNameField;

    private JButton btnAddVehicle, btnVoteVehicle, btnRetrieveRecords, btnExitApp;
    private Font titleFont, labelFont, buttonFont;

    private static JTextArea outputTextArea;
    CarVotingDAO vehicleDAO;

    public CarVotingClient() {
        super("Car of the Year");

        headerPanel = new JPanel();
        contentPanel = new JPanel();
        inputPanel = new JPanel();
        displayPanel = new JPanel();
        actionPanel = new JPanel();

        titleLabel = new JLabel("Car of the Year");
        vehicleNameLabel = new JLabel("Enter Vehicle Name: ");
        vehicleNameField = new JTextField(20);

        vehiclesLabel = new JLabel("Available Vehicles: ");
        vehicleComboBox = new JComboBox<>(new String[]{"Select Vehicle"});

        btnAddVehicle = new JButton("Add Vehicle");
        btnVoteVehicle = new JButton("Vote");
        btnRetrieveRecords = new JButton("Retrieve Records");
        btnExitApp = new JButton("Exit");
        titleFont = new Font("Times New Roman", Font.BOLD, 28);
        labelFont = new Font("Times New Roman", Font.PLAIN, 18);
        buttonFont = new Font("Times New Roman", Font.PLAIN, 20);

        connectToServer();
        setUp();

        vehicleDAO = new CarVotingDAO();

        ArrayList<CarVoting> vehicleList = vehicleDAO.getAll();
        for (CarVoting vehicle : vehicleList) {
            vehicleComboBox.addItem(vehicle.getVehicle());
        }
    }

    public void setUp() {
        headerPanel.setLayout(new FlowLayout());
        contentPanel.setLayout(new GridLayout(2, 1));
        inputPanel.setLayout(new FlowLayout());
        displayPanel.setLayout(new BorderLayout());
        actionPanel.setLayout(new GridLayout(1, 4));
        headerPanel.add(titleLabel);
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(Color.white); // Keep this if you want white text
        headerPanel.setBackground(new Color(255, 105, 180)); // A bright pink color

        vehiclesLabel.setFont(labelFont);
        vehicleComboBox.setFont(labelFont);
        inputPanel.add(vehiclesLabel);
        inputPanel.add(vehicleComboBox);
        inputPanel.add(vehicleNameLabel);
        inputPanel.add(vehicleNameField);

        outputTextArea = new JTextArea(10, 40);
        outputTextArea.setEditable(false);
        displayPanel.add(new JScrollPane(outputTextArea), BorderLayout.SOUTH);
        displayPanel.setBackground(new Color(0, 180, 255));

        btnAddVehicle.setFont(buttonFont);
        btnVoteVehicle.setFont(buttonFont);
        btnRetrieveRecords.setFont(buttonFont);
        btnExitApp.setFont(buttonFont);
        actionPanel.add(btnAddVehicle);
        actionPanel.add(btnVoteVehicle);
        actionPanel.add(btnRetrieveRecords);
        actionPanel.add(btnExitApp);

        this.add(headerPanel, BorderLayout.NORTH);
        this.add(contentPanel, BorderLayout.CENTER);
        this.add(actionPanel, BorderLayout.SOUTH);

        contentPanel.add(inputPanel);
        contentPanel.add(displayPanel);

        btnAddVehicle.addActionListener(this);
        btnVoteVehicle.addActionListener(this);
        btnRetrieveRecords.addActionListener(this);
        btnExitApp.addActionListener(this);

        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setSize(900, 600);
        this.setVisible(true);
        this.setLocationRelativeTo(null);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAddVehicle) {
            if (!vehicleNameField.getText().equals("")) {
                addNewVehicle();
            } else {
                JOptionPane.showMessageDialog(null, "Enter vehicle name");
            }
        } else if (e.getSource() == btnVoteVehicle) {
            if (vehicleComboBox.getSelectedIndex() != 0) {
                castVote(vehicleComboBox.getSelectedItem().toString());
            } else {
                JOptionPane.showMessageDialog(null, "Select a vehicle");
            }
        } else if (e.getSource() == btnRetrieveRecords) {
            retrieveVotingRecords();
        } else if (e.getSource() == btnExitApp) {
            closeConnection();
        }
    }

    private void addNewVehicle() {
        try {
            CarVoting newVehicle = new CarVoting(vehicleNameField.getText(), 0);
            output.writeObject(newVehicle);
            output.flush();

            ArrayList<CarVoting> vehicleList = (ArrayList<CarVoting>) input.readObject();
            vehicleComboBox.removeAllItems();
            for (CarVoting vehicle : vehicleList) {
                vehicleComboBox.addItem(vehicle.getVehicle());
                vehicleComboBox.addItem("Select a vehicle");
            }
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(CarVotingClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void connectToServer() {
        try {
            connection = new Socket("127.0.0.1", 1234);
            output = new ObjectOutputStream(connection.getOutputStream());
            output.flush();
            input = new ObjectInputStream(connection.getInputStream());
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Failed to connect to server");
        }
    }

    private void castVote(String vehicleName) {
        try {
            output.writeObject(vehicleName);
            output.flush();
        } catch (IOException ex) {
            Logger.getLogger(CarVotingClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

//    private void retrieveVotingRecords() {
//        try {
//            output.writeObject("retrieve");
//            output.flush();
//
//            String voteResults = (String) input.readObject();
//            outputTextArea.setText("");
//            outputTextArea.append(voteResults + "\n");
//
//        } catch (ClassNotFoundException | IOException ex) {
//            Logger.getLogger(CarVotingClient.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//   import javax.swing.*;
    private void retrieveVotingRecords() {
        try {
            output.writeObject("retrieve");
            output.flush();

            // Read data from the server
            String voteResults = (String) input.readObject();

            // Clear existing content if necessary
            outputTextArea.setText("");

            // Split the data based on a delimiter (e.g., newline for rows)
            String[] rows = voteResults.split("\n");

            // Create a table model with columns: "Name of car" and "Number of votes"
            DefaultTableModel model = new DefaultTableModel(new String[]{"Name of car", "Number of votes"}, 1);
            JTable table = new JTable(model);
            JScrollPane scrollPane = new JScrollPane(table);

            // Iterate over each row and split data based on comma
            for (String row : rows) {
                String[] rowData = row.split(",");
                if (rowData.length == 2) { // Ensure there are exactly two elements in each row
                    String carName = rowData[0].trim();
                    String votes = rowData[1].trim();
                    model.addRow(new Object[]{carName, votes});
                }

            }

            // Display the table (assume you have a JPanel named panel to add the table to)
            displayPanel.removeAll(); // Clear existing content if needed
            displayPanel.add(scrollPane);
            displayPanel.revalidate();
            displayPanel.repaint();

        } catch (ClassNotFoundException | IOException ex) {
            Logger.getLogger(CarVotingClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void closeConnection() {
        try {
            output.writeObject("exit");
            output.flush();
            input.close();
            output.close();
            connection.close();
            System.exit(0);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Failed to close connection");
        }
    }

    public static void main(String[] args) {
        CarVotingClient carVotingClient = new CarVotingClient();
    }
}
