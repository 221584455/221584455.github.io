
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class CarVotingDAO {
    private Connection con;
    private PreparedStatement pstmt;

    public CarVotingDAO() {
        try {
            this.con = DBConnection.derbyConnection();
        } catch (SQLException ex) {
            Logger.getLogger(CarVotingDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public CarVoting save(CarVoting carVote){
     int ok;
        String insertSql = "INSERT INTO CarVoting VALUES (?, ?)";
        try {
            pstmt = this.con.prepareStatement(insertSql);
            pstmt.setString(1, carVote.getVehicle());
            pstmt.setInt(2, carVote.getNumVotes());
            ok = pstmt.executeUpdate();
            if (ok > 0) {
                return carVote;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        } finally {
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException ex) {
                    Logger.getLogger(CarVotingDAO.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        return null;
    }
    
      public ArrayList<CarVoting> getAll() {
        ArrayList<CarVoting> votingList = new ArrayList<>();
        String getAllSql = "SELECT * FROM CarVoting";
        try {
            pstmt = this.con.prepareStatement(getAllSql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                System.out.println("DB table record: " + rs.getString(1) + " " + rs.getString(2));
                votingList.add(new CarVoting(rs.getString(1), rs.getInt(2)));
            }
            rs.close();
        } catch (SQLException ex) {
            System.out.println("ERROR: " + ex.getMessage());
        }
        return votingList;
    }
  public boolean updateVotes(String vehicle) {
    String updateSql = "UPDATE CarVoting SET NUMVOTES = NUMVOTES + 1 WHERE VEHICLE = ?";
    try {
        pstmt = this.con.prepareStatement(updateSql);
        pstmt.setString(1, vehicle);
        int ok = pstmt.executeUpdate();
        if (ok > 0) {
            return true;
        } else {
            return false; 
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        return false;
    } finally {
        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException ex) {
                Logger.getLogger(CarVotingDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
}
