
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
       public static Connection derbyConnection() throws SQLException {
           System.out.println("INSIDE CONN");
        String url = "jdbc:derby://localhost:1527/CarVotingDB";
        String username = "admin1";
        String password = "password";
        
        Connection conn = DriverManager.getConnection(url, username, password);
         System.out.println(" CONNECTED");
        return conn;
        
    }
}
