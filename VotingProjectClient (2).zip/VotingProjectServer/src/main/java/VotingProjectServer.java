/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author Mbasa Cabane
 */
public class VotingProjectServer {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
