


import java.io.Serializable;

public class CarVoting implements Serializable{
    private static final long serialVersionUID = 1L;
    private String vehicle;
    private int numVotes;


    public CarVoting(String vehicle, int numVotes) {
        this.vehicle = vehicle;
        this.numVotes = numVotes;
    }

   @Override
public String toString() {
    return vehicle + "," + numVotes;
}



    public String getVehicle() {
        return vehicle;
    }

    public void setVehicle(String vehicle) {
        this.vehicle = vehicle;
    }

    public int getNumVotes() {
        return numVotes;
    }

    public void setNumVotes(int numVotes) {
        this.numVotes = numVotes;
    }

 
    
}
