import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import javax.swing.*;

public class CarVotingServer {

    private static ObjectOutputStream out;
    private static ObjectInputStream in;
    private static ServerSocket serverSocket;
    private static Socket clientSocket;
    private static Object receivedObject;
    CarVotingDAO dao;
    private JTextArea logTextArea;

    public CarVotingServer() {
        // Set up the GUI
        JFrame frame = new JFrame("Car Voting Server");
        frame.setSize(500, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        logTextArea = new JTextArea();
        logTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logTextArea);
        frame.add(scrollPane);

        frame.setVisible(true);

        int port = 1234;
        try {
            serverSocket = new ServerSocket(port);
            log("Server is listening on port " + port);

            clientSocket = serverSocket.accept();
            log("Client connected");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Connection in server failed");
        }
        dao = new CarVotingDAO();
    }

    public void getStreams() {
        try {
            out = new ObjectOutputStream(clientSocket.getOutputStream());
            out.flush();
            in = new ObjectInputStream(clientSocket.getInputStream());
            log("Streams established");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Failed to get streams");
        }
    }

//    public void processClient() {
//        while (true) {
//            try {
//                receivedObject = in.readObject();
//
//                if (receivedObject instanceof CarVoting) {
//                    CarVoting savedCar = dao.save((CarVoting) receivedObject);
//                    if (savedCar != null) {
//                        log("New car added: " + savedCar.getVehicle());
//                        ArrayList<CarVoting> records = dao.getAll();
//                        out.writeObject(records);
//                        out.flush();
//                    }
//                } else if (((String) receivedObject).equals("retrieve")) {
//                    ArrayList<CarVoting> votingRecords = dao.getAll();
//                    StringBuilder data = new StringBuilder();
//                    for (CarVoting record : votingRecords) {
//                        data.append(record.getVehicle()).append(", ").append(record.getNumVotes()).append("\n");
//                    }
//                    out.writeObject(data.toString());
//                    out.flush();
//                    log("Vote records sent to client");
//                } else if (((String) receivedObject).equals("exit")) {
//                    log("Client requested to exit");
//                    closeConnection();
//                    break;
//                } else {
//                    ArrayList<CarVoting> votingRecords = dao.getAll();
//                    for (CarVoting votingRecord : votingRecords) {                        
//                        if (((String) receivedObject).equals(votingRecord.getVehicle())) {
//                            dao.updateVotes((String) receivedObject);
//                            log("Votes updated for car: " + votingRecord.getVehicle());
//                        }
//                    }
//                }
//
//            } catch (IOException ex) {
//                log("Error in processClient");
//                break;
//            } catch (ClassNotFoundException ex) {
//                log("Class not found in server");
//            }
//        }
//    }
    public void processClient() {
    while (true) {
        try {
            receivedObject = in.readObject();
            log("Received object: " + receivedObject.getClass().getSimpleName());

            if (receivedObject instanceof CarVoting) {
                log("Received a CarVoting object");
                CarVoting savedCar = dao.save((CarVoting) receivedObject);

                if (savedCar != null) {
                    log("New car added: " + savedCar.getVehicle());
                    ArrayList<CarVoting> records = dao.getAll();
                    out.writeObject(records);
                    out.flush();
                    log("Car list sent to client");
                } else {
                    log("Error: Failed to save the car");
                }
            } else if (receivedObject instanceof String) {
                String command = (String) receivedObject;
                log("Received command: " + command);

                if (command.equals("retrieve")) {
                    ArrayList<CarVoting> votingRecords = dao.getAll();
                    StringBuilder data = new StringBuilder();
                    for (CarVoting record : votingRecords) {
                        data.append(record.getVehicle()).append(", ").append(record.getNumVotes()).append("\n");
                    }
                    out.writeObject(data.toString());
                    out.flush();
                    log("Vote records sent to client");
                } else if (command.equals("exit")) {
                    log("Client requested to exit");
                    closeConnection();
                    break;
                } else {
                    ArrayList<CarVoting> votingRecords = dao.getAll();
                    boolean voteUpdated = false;
                    for (CarVoting votingRecord : votingRecords) {
                        if (command.equals(votingRecord.getVehicle())) {
                            dao.updateVotes(command);
                            log("Votes updated for car: " + votingRecord.getVehicle());
                            voteUpdated = true;
                        }
                    }
                    if (!voteUpdated) {
                        log("No matching car found for the update command");
                    }
                }
            } else {
                log("Unknown object type received");
            }

        } catch (IOException ex) {
            log("Error in processClient: " + ex.getMessage());
            break;
        } catch (ClassNotFoundException ex) {
            log("Class not found in server");
        }
    }
}


    public void closeConnection() {
        try {
            out.close();
            in.close();
            clientSocket.close();
            serverSocket.close();
            log("Server closing connections");
            System.exit(0);
        } catch (IOException ex) {
            log("Error closing connection");
        }
    }

    private void log(String message) {
        logTextArea.append(message + "\n");
    }

    public static void main(String[] args) {
        CarVotingServer server = new CarVotingServer();
        server.getStreams();
        server.processClient();
    }
}
